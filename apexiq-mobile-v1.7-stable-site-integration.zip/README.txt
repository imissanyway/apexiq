ApexIQ Mobile v1.7 stable site integration

Included:
- Full legend sticker pack browser
- Transparent PNG assets stored as files
- Sticker tap inserts into composer
- Forum feed renders sticker images
- Larger + emoji dock button
- Added Sparrow pack
